# Car-Parking-System-using-OpenCV
Using OpenCV and Python, it detects whether the parking spot is occupied or available, updates Google's Firebase with the data in real time.

![screenshot_20171227-115656](https://user-images.githubusercontent.com/9828402/34389232-1daf5b5a-eafe-11e7-8a43-0f721e760c9b.jpg)

![screenshot_20171227-115753](https://user-images.githubusercontent.com/9828402/34389219-0e316150-eafe-11e7-8bee-ad13f79940ae.jpg)
